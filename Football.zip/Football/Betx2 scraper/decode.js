// decode.js
const Module = require('./deportes.worker.js');

// Exemple de réponse chiffrée reçue du serveur
const encoded = "_&M`&>61(&J&>&Pefha$Pajjmw&(&ACJ&>jqhh(&AG&>7(&TPHAG&>4(&JTPHAG&>7(&HMG&>4(&HWG&>4(&WkvpM`&>2(&Tvmkvmp}&>=4(&GWL&>jqhh(&HA&>behwa(&GJP&>_Yy(&M`&>55<(&J&>&Rmvpqeh $Wtkvp&(&ACJ&>jqhh(&AG&>=4(&TPHAG&>4(&JTPHAG&>=4(&HMG&>4(&HWG&>4(&WkvpM`&>4(&Tvmkvmp}&>144(&GWL&>jqhh(&HA&>behwa(&GJP&>_Yy(&M`&>72(&J&>&Gvmgoap&(&ACJ&>jqhh(&AG&>7(&TPHAG&>4(&JTPHAG&>7(&HMG&>4(&HWG&>4(&WkvpM`&>75(&Tvmkvmp}&>144(&GWL&>jqhh(&HA&>behwa(&GJP&>_YyY";

// 1) Instanciation du module WASM
Module().then(m => {
  // 2) On crée un wrapper JS autour de la fonction _Deportes4 qui retourne une chaîne
  const decode = m.cwrap('Deportes4', 'string', ['string']);

  // 3) On décode
  const decoded = decode(encoded);

  console.log("✅ Décodé :", decoded);
}).catch(err => {
  console.error("❌ Erreur lors du chargement du module WASM :", err);
});
