# cookies.py - Shared cookie configuration for HTTP requests

# Cookie string that can be used by multiple scripts
COOKIE_STRING = "*ym*uid=1747951424123698040; *ym*d=1747951424; *hjSessionUser*5188126=eyJpZCI6Ijc2YTQwM2JkLWNhN2EtNTY4Mi04M2RlLTgzY2JhNjE0NjA4NiIsImNyZWF0ZWQiOjE3NDc5NTE0MjM4NDYsImV4aXN0aW5nIjpmYWxzZX0=; *ga*EDR7WTLZYX=GS2.1.s1747956658$o2$g0$t1747956658$j0$l0$h0; *ga*KR70V4CW7R=GS2.1.s1747956658$o2$g0$t1747956658$j0$l0$h0; *ga*LYB6EQTLPV=GS2.1.s1747956658$o2$g0$t1747956658$j0$l0$h0; __cf_bm=4QygJeEEcrThpjU3m0kefvr.q0mDHadGladychJt5wE-1748216347-1.0.1.1-u3IdQa8hqSf6NgYWueiNGQ10dD9UMZ3Yld8IBXqMHBUeetwhEsnMa0HC4FryTlilMDtIH.TrU8zPYBXoiz_XmAlsi26Kct9FLYPV4aN4gB0; *cfuvid=WAydQ2cBiEvMaj*AJZPhqc_dTWGuniGxbNk_dOsv9mM-1748216347094-0.0.1.1-604800000; cf_clearance=6w0E5NId1oqoSRKiB7c8hdqycl2mbsst_.f5xu3SFVM-1748216348-1.2.1.1-ZJgJBo5en5HEzB_YtJsA5BKFi99cB6RVuyjyDjuHUAE077DvL9QsvT48D9zP063vk9dX2lpWqKyfax7hM2beAgjUSrg11BijhtwvxsDjMejo4gds0Ft_IUe6qdEHiMpoNjx8uz42KOGUpOq.GbxocKj.hGlj0s6sIXq.guoX09auA8.kHGj1zxj8YcVJwVZGXE6Ia9EdpSGeweWt6j8wULjJtABq6t8o.oDZjmVY.y4D1EatghgZPBI1KaOnAXAv9tj7o2OPuZrasq_eZNUwiEPGOQIJbyaJCgdRtfV2aiYcBy4LntcHJd_qaxrOZc9mDG46PP1Ai6oriTKfOeMf9h9iBMlUzXNpCOt8qIsUVvM; *ga*YXTG4LX4D7=GS2.1.s1748216348$o7$g0$t1748216348$j0$l0$h0; *ga=GA1.2.93027829.1745186837; *gid=GA1.2.1432594447.1748216349; *gat=1; *_cfruid=b727a77b3c59306323ce484b3477558bde39b2a9-1748216351; ak_bmsc=EE98D6A716B8E220546016DA66331C64~000000000000000000000000000000~YAAQX/XnKfrYHPeWAQAALq7QCRv+gmJ+/rnwtsG0ARHQOArq8UqdsbQ2hgSCBfyo7zkw5MSeitug7iGrQuKG4TLUeZW9pMKfXlyX6Kq9IhlR2+7F9GjKhwsTKaGnDoKtOxUwbiw4nPYU0k++T6IlSu51iouGRtBCTxx2jzEEDJ4eoDw47RbUIEzGdFLa8N6hAMsNDjI/JUSwTd1F8EAt042YRcucMaMWcu1uk5enG59kRFW+RJwozaaiwmG/iyuWnQYhIy8HMl2q63WJXlnx8ODOygmb7J8AJvNkhqKSB09Sln3g/hTUwGtDY2Mld98PEBrr4tsaCG0tII0/aCD+qKsQtymBgOTUTOHa+VbIfzzebCA8BNFiuad9AsgB/8m337YUws1tRVYMiSlzIJxQFfkO5adXxq55LyvCZCjNPQVxj3yvfcaCCj4X5e2d4tfCIF2dTQ==; bm_mi=5B42D5B2141594735ADC3F6DBF55B350~YAAQX/XnKQnZHPeWAQAAh7TQCRt2AqA6vQZKcJIcuot+VdR41KQU/7lkynlqPPN471WZg8tbwWYS8dpPJR7ldhAJ2qSit+53I3yE81DUWAhIoSat3LAuTLkYxpWrrf/3y6hiSWsfHj6tVit54w+ZgwzO6Snf+RgIY32fxNnf567lmnVV/6N15g5K1c+qXlZJs9GH168FqjAPTCJklneg6rqkEF/ihjZeLyCz1Bj0axrsDb1SGHiWvfG3uM2ikJyOMi08nJdWFwO2Pt0zDCMuw4Qnrk1l4+xF9ogWtLyp1SGPobrlYqa2AfPCHxChbZjkXAkNJCOx7ikq2Z1f2gRX8K8KKlicggKXaYzBubV4jxLUVZm7gvISjv28toPyf9OE3pA4w0WsnQe2Pn5fWD78ofp5~1; bm_sv=CFA29C17AACAF4A9238D75BF9B98F8FC~YAAQX/XnKS7ZHPeWAQAAasXQCRtn88aUn5LPo7uKLONLLPG7Nz9ARw/CupUfQz8SP+zNkJetaYRFotvrH/1pZDEK/rW79ICoEU9r0dnVJcaXHv24PKtOq+mdA1o25gJupUvfWrlnBQdY7bpFG2UOKqk7226jUCEYcX1AHSmYd4nkGCLUu5GKOjwMGedksScEEGLxNkPsu5oh666uGUlz8raiPd4MI9wnWbsh+WLOtLuOds0EeSMuFJrQCd7rKZU=~1"

# Common User-Agent string
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"

# Common headers that can be reused
COMMON_HEADERS = {
    'Host': 'sport.betx2.com',
    'Cookie': COOKIE_STRING,
    'User-Agent': USER_AGENT,
    'Accept': '*/*',
    'Referer': 'https://sport.betx2.com/',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9'
}

def get_cookie_string():
    """Return the cookie string"""
    return COOKIE_STRING

def get_common_headers():
    """Return a copy of common headers"""
    return COMMON_HEADERS.copy()

def update_cookies(new_cookie_string):
    """Update the cookie string (useful for refreshing session)"""
    global COOKIE_STRING, COMMON_HEADERS
    COOKIE_STRING = new_cookie_string
    COMMON_HEADERS['Cookie'] = COOKIE_STRING
    print("Cookies updated successfully!")