import wasmtime
import base64
import requests
import datetime
import json
import os
import re
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk


def select_file_dialog(title="Select File", filetypes=None):
    """Open file dialog to select a file"""
    if filetypes is None:
        filetypes = [
            ("JavaScript files", "*.js"),
            ("WASM files", "*.wasm"),
            ("Text files", "*.txt"),
            ("All files", "*.*")
        ]

    root = tk.Tk()
    root.withdraw()  # Hide the main window

    file_path = filedialog.askopenfilename(
        title=title,
        filetypes=filetypes,
        initialdir=os.getcwd()
    )

    root.destroy()
    return file_path


def select_multiple_files_dialog(title="Select Files", filetypes=None):
    """Open file dialog to select multiple files"""
    if filetypes is None:
        filetypes = [
            ("Text files", "*.txt"),
            ("JSON files", "*.json"),
            ("All files", "*.*")
        ]

    root = tk.Tk()
    root.withdraw()  # Hide the main window

    file_paths = filedialog.askopenfilenames(
        title=title,
        filetypes=filetypes,
        initialdir=os.getcwd()
    )

    root.destroy()
    return file_paths


def show_results_dialog(title, content, max_chars=2000):
    """Show results in a dialog window"""
    root = tk.Tk()
    root.title(title)
    root.geometry("800x600")

    # Create text widget with scrollbar
    frame = ttk.Frame(root)
    frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    text_widget = tk.Text(frame, wrap=tk.WORD)
    scrollbar = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=text_widget.yview)
    text_widget.configure(yscrollcommand=scrollbar.set)

    # Pack widgets
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Insert content (truncated if too long)
    display_content = content[:max_chars]
    if len(content) > max_chars:
        display_content += f"\n\n... (Content truncated. Full length: {len(content)} characters)"

    text_widget.insert(tk.END, display_content)
    text_widget.config(state=tk.DISABLED)

    # Add buttons
    button_frame = ttk.Frame(root)
    button_frame.pack(fill=tk.X, padx=10, pady=(0, 10))

    def save_to_file():
        save_path = filedialog.asksaveasfilename(
            title="Save content to file",
            defaultextension=".txt",
            filetypes=[
                ("Text files", "*.txt"),
                ("JSON files", "*.json"),
                ("All files", "*.*")
            ]
        )
        if save_path:
            try:
                with open(save_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                messagebox.showinfo("Success", f"Content saved to {save_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save file: {e}")

    ttk.Button(button_frame, text="Save to File", command=save_to_file).pack(side=tk.LEFT, padx=(0, 10))
    ttk.Button(button_frame, text="Close", command=root.destroy).pack(side=tk.RIGHT)

    root.mainloop()


def interactive_file_selector():
    """Interactive menu for file selection and processing"""
    print("Betx2 WASM Decoder - Interactive Mode")
    print("=" * 40)

    while True:
        print("\nChoose an option:")
        print("1. Load JavaScript file and extract WASM")
        print("2. Load WASM file directly")
        print("3. Load obfuscated response file to decode")
        print("4. Make live API request and decode")
        print("5. Test with sample data")
        print("6. Exit")

        try:
            choice = input("\nEnter your choice (1-6): ").strip()

            if choice == '1':
                handle_js_file_selection()
            elif choice == '2':
                handle_wasm_file_selection()
            elif choice == '3':
                handle_response_file_selection()
            elif choice == '4':
                handle_live_api_request()
            elif choice == '5':
                handle_sample_test()
            elif choice == '6':
                print("Goodbye!")
                break
            else:
                print("Invalid choice. Please enter 1-6.")

        except KeyboardInterrupt:
            print("\n\nGoodbye!")
            break
        except Exception as e:
            print(f"Error: {e}")


def handle_js_file_selection():
    """Handle JavaScript file selection and WASM extraction"""
    print("\nSelect JavaScript file containing WASM data...")

    js_file = select_file_dialog(
        title="Select JavaScript file",
        filetypes=[
            ("JavaScript files", "*.js"),
            ("All files", "*.*")
        ]
    )

    if not js_file:
        print("No file selected.")
        return

    print(f"Selected: {js_file}")

    try:
        decoder = DeportesDecoder()
        success = decoder.load_wasm_from_js_file(js_file)

        if success:
            print("WASM extracted and loaded successfully!")

            # Ask if user wants to test with sample data
            test = input("Test decoder with sample data? (y/n): ").lower()
            if test == 'y':
                sample_data = "@`9R9!),#*(./-79U9!9Otwnxz;6;X];Zv~irxz979^"
                result = decoder.decode_response(sample_data)
                if result:
                    print("Decoding successful!")
                    show_results_dialog("Decoded Result", result)
                else:
                    print("Decoding failed.")
        else:
            print("Failed to extract/load WASM from JavaScript file.")

    except Exception as e:
        print(f"Error processing JavaScript file: {e}")


def handle_wasm_file_selection():
    """Handle WASM file selection"""
    print("\nSelect WASM file...")

    wasm_file = select_file_dialog(
        title="Select WASM file",
        filetypes=[
            ("WASM files", "*.wasm"),
            ("All files", "*.*")
        ]
    )

    if not wasm_file:
        print("No file selected.")
        return

    print(f"Selected: {wasm_file}")

    try:
        decoder = DeportesDecoder(wasm_file)
        print("WASM file loaded successfully!")

        # Ask if user wants to test with sample data
        test = input("Test decoder with sample data? (y/n): ").lower()
        if test == 'y':
            sample_data = "@`9R9!),#*(./-79U9!9Otwnxz;6;X];Zv~irxz979^"
            result = decoder.decode_response(sample_data)
            if result:
                print("Decoding successful!")
                show_results_dialog("Decoded Result", result)
            else:
                print("Decoding failed.")

    except Exception as e:
        print(f"Error loading WASM file: {e}")


def handle_response_file_selection():
    """Handle obfuscated response file selection"""
    print("\nSelect obfuscated response file(s) to decode...")

    response_files = select_multiple_files_dialog(
        title="Select obfuscated response file(s)",
        filetypes=[
            ("Text files", "*.txt"),
            ("All files", "*.*")
        ]
    )

    if not response_files:
        print("No files selected.")
        return

    print(f"Selected {len(response_files)} file(s)")

    # Ask for decoder source
    print("\nChoose decoder source:")
    print("1. Extract from JavaScript file")
    print("2. Use existing WASM file")
    print("3. Try simple decoding methods only")

    decoder_choice = input("Enter choice (1-3): ").strip()

    decoder = None

    if decoder_choice == '1':
        js_file = select_file_dialog(
            title="Select JavaScript file with WASM",
            filetypes=[("JavaScript files", "*.js"), ("All files", "*.*")]
        )
        if js_file:
            decoder = DeportesDecoder()
            decoder.load_wasm_from_js_file(js_file)

    elif decoder_choice == '2':
        wasm_file = select_file_dialog(
            title="Select WASM file",
            filetypes=[("WASM files", "*.wasm"), ("All files", "*.*")]
        )
        if wasm_file:
            decoder = DeportesDecoder(wasm_file)

    elif decoder_choice == '3':
        # Simple decoding only
        pass
    else:
        print("Invalid choice.")
        return

    # Process each file
    for response_file in response_files:
        print(f"\nProcessing: {os.path.basename(response_file)}")

        try:
            with open(response_file, 'r', encoding='utf-8') as f:
                obfuscated_data = f.read().strip()

            print(f"Loaded obfuscated data (length: {len(obfuscated_data)})")

            decoded_result = None

            # Try WASM decoding if decoder available
            if decoder:
                decoded_result = decoder.decode_response(obfuscated_data)

            # If WASM failed or not available, try simple methods
            if not decoded_result:
                print("Trying simple decoding methods...")
                simple_decodings = try_simple_decodings(obfuscated_data)

                if simple_decodings:
                    # Show all possible decodings
                    results_text = "Multiple possible decodings found:\n\n"
                    for i, (method, result) in enumerate(simple_decodings, 1):
                        results_text += f"Method {i}: {method}\n"
                        results_text += f"Result: {result[:200]}{'...' if len(result) > 200 else ''}\n\n"

                    show_results_dialog(f"Decoding Results - {os.path.basename(response_file)}", results_text)
                else:
                    print("No successful decodings found.")
            else:
                print("WASM decoding successful!")
                show_results_dialog(f"Decoded Result - {os.path.basename(response_file)}", decoded_result)

        except Exception as e:
            print(f"Error processing {response_file}: {e}")


def handle_live_api_request():
    """Handle live API request"""
    print("\nMaking live API request...")
    confirm = input("This will make a request to betx2.com. Continue? (y/n): ").lower()

    if confirm != 'y':
        print("Cancelled.")
        return

    try:
        response = make_events_api_request_and_decode()
        if response:
            print("API request completed. Check the saved files for results.")
    except Exception as e:
        print(f"Error making API request: {e}")


def handle_sample_test():
    """Handle sample data test"""
    print("\nTesting with sample obfuscated data...")
    sample_data = "@`9R9!),#*(./-79U9!9Otwnxz;6;X];Zv~irxz979^"

    print("Choose decoder source:")
    print("1. Extract from JavaScript file")
    print("2. Use existing WASM file")
    print("3. Try simple decoding methods only")

    choice = input("Enter choice (1-3): ").strip()

    if choice == '1':
        js_file = select_file_dialog(
            title="Select JavaScript file with WASM",
            filetypes=[("JavaScript files", "*.js"), ("All files", "*.*")]
        )
        if js_file:
            decoder = DeportesDecoder()
            if decoder.load_wasm_from_js_file(js_file):
                result = decoder.decode_response(sample_data)
                if result:
                    show_results_dialog("Sample Decode Result", result)
                else:
                    print("WASM decoding failed.")

    elif choice == '2':
        wasm_file = select_file_dialog(
            title="Select WASM file",
            filetypes=[("WASM files", "*.wasm"), ("All files", "*.*")]
        )
        if wasm_file:
            decoder = DeportesDecoder(wasm_file)
            result = decoder.decode_response(sample_data)
            if result:
                show_results_dialog("Sample Decode Result", result)
            else:
                print("WASM decoding failed.")

    elif choice == '3':
        simple_decodings = try_simple_decodings(sample_data)
        if simple_decodings:
            results_text = "Simple decoding results:\n\n"
            for method, result in simple_decodings:
                results_text += f"{method}: {result}\n\n"
            show_results_dialog("Simple Decoding Results", results_text)
        else:
            print("No simple decodings worked.")


class DeportesDecoder:
    def __init__(self, wasm_file_path=None):
        """Initialize the decoder with the WASM module"""
        self.engine = wasmtime.Engine()
        self.store = wasmtime.Store(self.engine)
        self.module = None
        self.instance = None
        self.memory = None

        if wasm_file_path:
            self.load_wasm_from_file(wasm_file_path)

    def load_wasm_from_js_file(self, js_file_path):
        """Extract and load WASM from a JavaScript file"""
        try:
            # Check if file exists
            if not os.path.exists(js_file_path):
                print(f"JavaScript file not found: {js_file_path}")
                return False

            # Read the JavaScript file
            with open(js_file_path, 'r', encoding='utf-8') as f:
                js_content = f.read()

            print(f"JavaScript file loaded (length: {len(js_content)})")

            # Multiple patterns to find base64 WASM data
            patterns = [
                r'data:application/octet-stream;base64,([A-Za-z0-9+/=]+)',
                r'data:application/wasm;base64,([A-Za-z0-9+/=]+)',
                r'"([A-Za-z0-9+/=]{1000,})"',  # Long base64 strings
                r"'([A-Za-z0-9+/=]{1000,})'",  # Single quotes
                r'base64,([A-Za-z0-9+/=]+)',  # Generic base64 pattern
            ]

            base64_data = None
            for pattern in patterns:
                matches = re.findall(pattern, js_content)
                if matches:
                    # Take the longest match (likely the WASM data)
                    base64_data = max(matches, key=len)
                    print(f"Found base64 data using pattern: {pattern}")
                    break

            if not base64_data:
                print("No base64 WASM data found in JS file")
                print("Searching for any large base64-like strings...")

                # More aggressive search
                long_strings = re.findall(r'[A-Za-z0-9+/=]{500,}', js_content)
                if long_strings:
                    base64_data = max(long_strings, key=len)
                    print(f"Found potential base64 data (length: {len(base64_data)})")

            if not base64_data:
                print("WASM base64 data not found in JS file")
                return False

            print(f"Extracted base64 WASM data (length: {len(base64_data)})")

            # Decode base64 to get WASM binary
            try:
                wasm_binary = base64.b64decode(base64_data)
            except Exception as e:
                print(f"Failed to decode base64: {e}")
                # Try cleaning the base64 string
                clean_base64 = re.sub(r'[^A-Za-z0-9+/=]', '', base64_data)
                wasm_binary = base64.b64decode(clean_base64)

            print(f"WASM binary decoded (size: {len(wasm_binary)} bytes)")

            # Save WASM binary for debugging
            wasm_save_path = js_file_path.replace('.js', '.wasm')
            with open(wasm_save_path, 'wb') as f:
                f.write(wasm_binary)
            print(f"WASM binary saved as {wasm_save_path}")

            # Load the WASM module
            return self._load_wasm_binary(wasm_binary)

        except Exception as e:
            print(f"Error loading WASM from JS: {e}")
            return False

    def load_wasm_from_js(self):
        """Load WASM from the default deportes.worker.js file"""
        return self.load_wasm_from_js_file('deportes.worker.js')

    def load_wasm_from_file(self, wasm_file_path):
        """Load WASM from a binary file"""
        try:
            if not os.path.exists(wasm_file_path):
                print(f"WASM file not found: {wasm_file_path}")
                return False

            with open(wasm_file_path, 'rb') as f:
                wasm_binary = f.read()

            print(f"WASM file loaded: {wasm_file_path} ({len(wasm_binary)} bytes)")
            return self._load_wasm_binary(wasm_binary)

        except Exception as e:
            print(f"Error loading WASM file: {e}")
            return False

    def _load_wasm_binary(self, wasm_binary):
        """Load WASM binary data"""
        try:
            # Compile the WASM module
            self.module = wasmtime.Module(self.engine, wasm_binary)
            print("WASM module compiled successfully")

            # Create instance
            self.instance = wasmtime.Instance(self.store, self.module, [])
            print("WASM instance created successfully")

            # Get memory if available
            memory_export = self.instance.exports(self.store).get("memory")
            if memory_export:
                self.memory = memory_export
                print("WASM memory accessible")

            # List available exports
            print("Available WASM exports:")
            exports = self.instance.exports(self.store)
            for name in exports:
                export_item = exports[name]
                print(f"  - {name}: {type(export_item).__name__}")

            return True

        except Exception as e:
            print(f"Error loading WASM binary: {e}")
            return False

    def decode_response(self, encoded_data):
        """Decode the obfuscated response data"""
        try:
            if not self.instance:
                print("WASM module not loaded")
                return None

            print(f"Attempting to decode data: {encoded_data[:100]}...")

            # Get exports
            exports = self.instance.exports(self.store)

            # Try different decoder function names
            decoder_functions = [
                'decode', 'decrypt', 'decompress', 'Deportes4', '_Deportes4',
                'deobfuscate', 'transform', 'process', 'main'
            ]

            decoded_data = None

            for func_name in decoder_functions:
                if func_name in exports:
                    try:
                        print(f"Trying function: {func_name}")
                        func = exports[func_name]

                        if isinstance(func, wasmtime.Func):
                            # Try calling with string data
                            if isinstance(encoded_data, str):
                                # Method 1: Try direct string call
                                try:
                                    result = func(self.store, encoded_data)
                                    if result:
                                        decoded_data = result
                                        print(f"Success with {func_name} (direct string)")
                                        break
                                except:
                                    pass

                                # Method 2: Try with bytes
                                try:
                                    data_bytes = encoded_data.encode('utf-8')
                                    result = func(self.store, data_bytes)
                                    if result:
                                        decoded_data = result
                                        print(f"Success with {func_name} (bytes)")
                                        break
                                except:
                                    pass

                                # Method 3: Try with length parameter
                                try:
                                    result = func(self.store, encoded_data, len(encoded_data))
                                    if result:
                                        decoded_data = result
                                        print(f"Success with {func_name} (with length)")
                                        break
                                except:
                                    pass

                    except Exception as e:
                        print(f"Function {func_name} failed: {e}")
                        continue

            # If no decoder function worked, try memory-based approach
            if not decoded_data and self.memory:
                decoded_data = self._try_memory_decode(encoded_data)

            return decoded_data

        except Exception as e:
            print(f"Error decoding response: {e}")
            return None

    def _try_memory_decode(self, encoded_data):
        """Try to decode using direct memory manipulation"""
        try:
            print("Attempting memory-based decoding...")

            exports = self.instance.exports(self.store)

            # Look for memory allocation functions
            malloc_func = exports.get('malloc') or exports.get('_malloc')
            free_func = exports.get('free') or exports.get('_free')

            if malloc_func and self.memory:
                data_bytes = encoded_data.encode('utf-8') if isinstance(encoded_data, str) else encoded_data
                data_len = len(data_bytes)

                # Allocate memory
                ptr = malloc_func(self.store, data_len)
                print(f"Allocated memory at pointer: {ptr}")

                # Write data to memory
                memory_data = self.memory.data(self.store)
                memory_data[ptr:ptr + data_len] = data_bytes

                # Try to find and call decoder with pointer
                for func_name in ['decode', 'decrypt', '_Deportes4', 'process']:
                    if func_name in exports:
                        try:
                            func = exports[func_name]
                            result = func(self.store, ptr, data_len)
                            if result and isinstance(result, int):
                                # Result is a pointer, read string from memory
                                decoded = self._read_string_from_memory(result)
                                if decoded:
                                    print(f"Memory decode success with {func_name}")
                                    if free_func:
                                        free_func(self.store, ptr)
                                    return decoded
                        except Exception as e:
                            print(f"Memory decode with {func_name} failed: {e}")

                # Free allocated memory
                if free_func:
                    free_func(self.store, ptr)

            return None

        except Exception as e:
            print(f"Memory decode failed: {e}")
            return None

    def _read_string_from_memory(self, ptr):
        """Read a null-terminated string from WASM memory"""
        try:
            if not self.memory:
                return None

            memory_data = self.memory.data(self.store)
            result = []
            i = 0

            while ptr + i < len(memory_data) and memory_data[ptr + i] != 0:
                result.append(chr(memory_data[ptr + i]))
                i += 1
                if i > 10000:  # Prevent infinite loop
                    break

            return ''.join(result) if result else None

        except Exception as e:
            print(f"Error reading string from memory: {e}")
            return None


def make_events_api_request_and_decode():
    """Make the API request and decode the response"""
    # Import here to avoid issues if cookies module doesn't exist
    try:
        from cookies import get_common_headers
    except ImportError:
        print("Warning: cookies module not found, using basic headers")

        def get_common_headers():
            return {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
            }

    # Base URL and endpoint
    base_url = "https://sport.betx2.com"
    endpoint = "/afdb6836-2b81-4931-a030-8a97d61a13d6/live/geteventslistwithstaketypes"

    # Exact query parameters from the request
    params = {
        'stakesId': [1, 702, 3, 2533, 2, 2532, 313638, 313639, 37, 402315],
        'sportId': 1,
        'langId': 2,
        'partnerId': 3000127,
        'countryCode': 'TN'
    }

    # Get common headers and add specific ones for this request
    headers = get_common_headers()
    headers.update({
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Ch-Ua': '"Not.A/Brand";v="99", "Chromium";v="136"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Priority': 'u=1, i'
    })

    # Full URL
    full_url = base_url + endpoint

    try:
        # Make the GET request
        print("Making Events API request...")
        print(f"URL: {full_url}")

        response = requests.get(full_url, params=params, headers=headers, timeout=30)
        print(f"Status Code: {response.status_code}")

        if response.status_code == 200:
            # Get the obfuscated response
            obfuscated_data = response.text
            print(f"Received obfuscated data (length: {len(obfuscated_data)})")

            # Initialize the decoder
            decoder = DeportesDecoder()

            # Decode the response
            decoded_data = decoder.decode_response(obfuscated_data)

            if decoded_data:
                print("Successfully decoded the response!")

                # Try to parse as JSON
                try:
                    json_data = json.loads(decoded_data)
                    print("Decoded data is valid JSON")

                    # Save both raw and formatted JSON
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

                    # Save raw decoded data
                    with open(f"decoded_response_{timestamp}.txt", 'w', encoding='utf-8') as f:
                        f.write(decoded_data)

                    # Save formatted JSON
                    with open(f"decoded_response_{timestamp}.json", 'w', encoding='utf-8') as f:
                        json.dump(json_data, f, indent=2, ensure_ascii=False)

                    print(f"Decoded data saved to decoded_response_{timestamp}.txt and .json")

                    # Print first few items for preview
                    print("\nPreview of decoded data:")
                    print(json.dumps(json_data, indent=2, ensure_ascii=False)[:1000] + "...")

                except json.JSONDecodeError:
                    print("Decoded data is not valid JSON")
                    # Save as plain text
                    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                    with open(f"decoded_response_{timestamp}.txt", 'w', encoding='utf-8') as f:
                        f.write(decoded_data)
                    print(f"Decoded data saved to decoded_response_{timestamp}.txt")
                    print(f"Preview: {decoded_data[:500]}...")
            else:
                print("Failed to decode the response")
                # Save the obfuscated data for analysis
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                with open(f"obfuscated_response_{timestamp}.txt", 'w', encoding='utf-8') as f:
                    f.write(obfuscated_data)
                print(f"Obfuscated data saved to obfuscated_response_{timestamp}.txt")

        return response

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {str(e)}")
        return None


def decode_existing_response(response_text):
    """Decode an existing obfuscated response"""
    try:
        print(f"Decoding existing response (length: {len(response_text)})")

        # Initialize the decoder
        decoder = DeportesDecoder()

        # Decode the response
        decoded_data = decoder.decode_response(response_text)

        if decoded_data:
            print("Successfully decoded the response!")

            # Try to parse as JSON
            try:
                json_data = json.loads(decoded_data)
                print("Decoded data is valid JSON")

                # Save both raw and formatted JSON
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

                with open(f"decoded_existing_{timestamp}.json", 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=2, ensure_ascii=False)

                print(f"Decoded data saved to decoded_existing_{timestamp}.json")
                return json_data

            except json.JSONDecodeError:
                print("Decoded data is not valid JSON")
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                with open(f"decoded_existing_{timestamp}.txt", 'w', encoding='utf-8') as f:
                    f.write(decoded_data)
                print(f"Decoded data saved to decoded_existing_{timestamp}.txt")
                return decoded_data
        else:
            print("Failed to decode the response")
            return None

    except Exception as e:
        print(f"Error decoding existing response: {e}")
        return None


# Alternative simple decoding approaches if WASM fails
def try_simple_decodings(encoded_data):
    """Try simple decoding methods"""
    print("Trying simple decoding methods...")

    decodings = []

    # Method 1: Base64 decode
    try:
        decoded = base64.b64decode(encoded_data).decode('utf-8')
        decodings.append(("Base64", decoded))
    except:
        pass

    # Method 2: URL decode
    try:
        import urllib.parse
        decoded = urllib.parse.unquote(encoded_data)
        decodings.append(("URL decode", decoded))
    except:
        pass

    # Method 3: Simple Caesar cipher (try different shifts)
    for shift in range(1, 26):
        try:
            decoded = ''.join(chr((ord(c) - shift) % 256) for c in encoded_data)
            if decoded.isprintable():
                decodings.append((f"Caesar shift -{shift}", decoded))
        except:
            pass

    # Method 4: XOR with common keys
    common_keys = [0x42, 0x13, 0x37, 0xFF, 0xAA, 0x55]
    for key in common_keys:
        try:
            decoded = ''.join(chr(ord(c) ^ key) for c in encoded_data)
            if decoded.isprintable():
                decodings.append((f"XOR with 0x{key:02X}", decoded))
        except:
            pass

    return decodings


if __name__ == "__main__":
    print("Betx2 WASM Decoder")
    print("==================")

    # First, install required packages if needed
    try:
        import wasmtime
    except ImportError:
        print("Error: wasmtime not installed. Please install it with:")
        print("pip install wasmtime")
        exit(1)

    # Example usage with your obfuscated data
    sample_obfuscated = "@`9R9!),#*(./-79U9!9Otwnxz;6;X];Zv~irxz979^"

    print(f"Testing with sample obfuscated data: {sample_obfuscated}")
    print("-" * 50)

    # Try WASM decoding
    decoded = decode_existing_response(sample_obfuscated)

    if not decoded:
        print("\nWASM decoding failed, trying simple methods...")
        simple_decodings = try_simple_decodings(sample_obfuscated)

        if simple_decodings:
            print("Possible simple decodings found:")
            for method, result in simple_decodings:
                print(f"{method}: {result[:100]}...")
        else:
            print("No simple decodings worked either.")

    # Uncomment to make live API request and decode
    # print("\nMaking live API request...")
    # response = make_events_api_request_and_decode()