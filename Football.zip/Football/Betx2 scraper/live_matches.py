import requests
import datetime
import json
from cookies import get_common_headers


def make_events_api_request():
    # Base URL and endpoint
    base_url = "https://sport.betx2.com"
    endpoint = "/afdb6836-2b81-4931-a030-8a97d61a13d6/live/geteventslistwithstaketypes"

    # Exact query parameters from the request
    params = {
        'stakesId': [1, 702, 3, 2533, 2, 2532, 313638, 313639, 37, 402315],
        'sportId': 1,
        'langId': 2,
        'partnerId': 3000127,
        'countryCode': 'TN'
    }

    # Get common headers and add specific ones for this request
    headers = get_common_headers()
    headers.update({
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Ch-Ua': '"Not.A/Brand";v="99", "Chromium";v="136"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Priority': 'u=1, i'
    })

    # Full URL
    full_url = base_url + endpoint

    try:
        # Make the GET request
        print("Making Events API request...")
        print(f"URL: {full_url}")
        print(f"Parameters: {params}")

        response = requests.get(full_url, params=params, headers=headers, timeout=30)

        # Print request details
        print(f"Final Request URL: {response.url}")
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")

        # Get current timestamp for filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"events_api_response_{timestamp}.txt"

        # Save raw response to file
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(response.text)

        print(f"Raw response saved to: {filename}")

        return response

    except requests.exceptions.RequestException as e:
        error_msg = f"Request failed: {str(e)}"
        print(error_msg)

        # Save error to file
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"events_api_error_{timestamp}.txt"

        # Save raw error response to file
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(error_msg)

        print(f"Error details saved to: {filename}")
        return None


if __name__ == "__main__":
    response = make_events_api_request()
    if response:
        print("API request completed successfully!")
        if response.status_code == 200:
            print("Request was successful (200 OK)")
        else:
            print(f"Request completed with status code: {response.status_code}")
    else:
        print("API request failed. Check the error file for details.")