import re
import ctypes
import base64
import requests
import zlib
import datetime
from cookies import get_common_headers
from wasmtime import Engine, Store, Module, Instance, Func, FuncType, ValType


def extract_wasm(js_path: str, out_wasm: str):
    with open(js_path, 'r', encoding='utf-8') as f:
        js = f.read()
    m = re.search(r'data:application/octet-stream;base64,([A-Za-z0-9+/=]+)', js)
    if not m:
        raise RuntimeError("Couldn't find base64 wasm blob")
    wasm_bytes = base64.b64decode(m.group(1))
    with open(out_wasm, 'wb') as f:
        f.write(wasm_bytes)
    print(f"Extracted {out_wasm}")


def load_wasm(wasm_path: str):
    engine = Engine()
    store = Store(engine)
    module = Module(engine, open(wasm_path, 'rb').read())

    print("=== exports ===")
    for exp in module.exports:
        print(f"{exp.name}   →   {exp.type}")

    stub_a = Func(store, FuncType([], []), lambda: None)
    stub_b = Func(store, FuncType([ValType.i32()], [ValType.i32()]), lambda x: x)
    stub_c = Func(store, FuncType([ValType.i32(), ValType.i32(), ValType.i32()], []), lambda x, y, z: None)

    instance = Instance(store, module, [stub_a, stub_b, stub_c])
    exports = instance.exports(store)
    return store, exports


def make_decoder(store, exports):
    _decrypt = exports["i"]
    _malloc = exports["g"]
    memory = exports["d"]

    mem_ptr = int.from_bytes(memory.data_ptr(store), 'little', signed=False)
    mem_size = memory.data_len(store)

    WasmMemory = ctypes.c_uint8 * mem_size
    mem_buffer = WasmMemory.from_address(mem_ptr)

    def decode_response(raw: bytes) -> bytes:
        out = bytearray()
        chunk_size = 8192

        for offset in range(0, len(raw), chunk_size):
            chunk = raw[offset:offset + chunk_size]
            ptr = _malloc(store, len(chunk))
            print(f"[DEBUG] offset={offset}, len={len(chunk)}, ptr={ptr}")

            try:
                mem_buffer[ptr:ptr + len(chunk)] = chunk
            except Exception as e:
                print(f"[ERROR] writing to Wasm memory failed: {e}")
                print(f"[DEBUG] mem_size={mem_size}, ptr={ptr}, chunk_len={len(chunk)}")
                raise

            res_ptr = _decrypt(store, ptr)

            try:
                decrypted = bytes(mem_buffer[res_ptr:res_ptr + len(chunk) - 1])
            except Exception as e:
                print(f"[ERROR] reading from Wasm memory failed: {e}")
                raise

            out += decrypted

        # DEFLATE decompression step
        try:
            decompressed = zlib.decompress(out, -15)
        except Exception as e:
            print("[ERROR] zlib decompression failed:", e)
            raise

        return decompressed

    return decode_response


def make_events_api_request(decode_fn):
    base_url = "https://sport.betx2.com"
    endpoint = "/afdb6836-2b81-4931-a030-8a97d61a13d6/live/geteventslistwithstaketypes"
    params = {
        'stakesId': [1, 702, 3, 2533, 2, 2532, 313638, 313639, 37, 402315],
        'sportId': 1, 'langId': 2, 'partnerId': 3000127, 'countryCode': 'TN'
    }

    headers = get_common_headers()
    headers.update({
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Ch-Ua': '"Not.A/Brand";v="99", "Chromium";v="136"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Dest': 'empty',
        'Priority': 'u=1, i'
    })

    url = base_url + endpoint
    print("GET", url)
    resp = requests.get(url, params=params, headers=headers, timeout=30)
    print("Status code:", resp.status_code)

    if resp.status_code == 200:
        decoded = decode_fn(resp.content)
        text = decoded.decode('utf-8', errors='replace')
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = f"events_{ts}.json"
        with open(fname, 'w', encoding='utf-8') as f:
            f.write(text)
        print("Decoded response saved to", fname)
    else:
        print("Error response:", resp.text)


if __name__ == "__main__":
    # extract_wasm('deportes.worker.js', 'deportes.wasm')  # Only if not already extracted
    store, exports = load_wasm('deportes.wasm')
    print("WASM exports:", [e for e in exports.keys()])
    decoder = make_decoder(store, exports)
    make_events_api_request(decoder)
