import requests
import datetime
from cookies import get_common_headers


def make_http_request():
    # URL
    url = "https://sport.betx2.com/scripts/pkg7/deportes.worker.js"

    # Get common headers and add specific ones for this request
    headers = get_common_headers()
    headers.update({
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'no-cors',
        'Sec-Fetch-Dest': 'script',
        'Priority': 'u=0, i',
        'Content-Length': '2'
    })

    try:
        # Make the GET request
        print("Making HTTP request...")
        response = requests.get(url, headers=headers, timeout=30)

        # Print request details
        print(f"Request URL: {url}")
        print(f"Status Code: {response.status_code}")
        print(f"Response Headers: {dict(response.headers)}")

        # Get current timestamp for filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = "deportes.worker.js"

        # Save raw response to file
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(response.text)

        print(f"Raw response saved to: {filename}")

        return response

    except requests.exceptions.RequestException as e:
        error_msg = f"Request failed: {str(e)}"
        print(error_msg)

        # Save error to file
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"deportes_worker_error_{timestamp}.txt"

        # Save raw error to file
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(error_msg)

        print(f"Error details saved to: {filename}")
        return None


if __name__ == "__main__":
    response = make_http_request()
    if response:
        print("Request completed successfully!")
    else:
        print("Request failed. Check the error file for details.")